﻿using Datalager;

namespace Affärslager
{
    internal class FakturaKontroller
    {

        UnitOfWork unitOfWork = new UnitOfWork();
    }
}
