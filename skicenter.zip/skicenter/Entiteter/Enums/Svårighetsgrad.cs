﻿namespace Entiteter.Enums
{
    public enum Svårighetsgrad
    {
        Grön,
        Blå,
        Röd,
        Svart
    }
}
