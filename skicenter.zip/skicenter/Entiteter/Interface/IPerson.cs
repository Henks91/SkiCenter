﻿namespace Entiteter.Interface
{
    public interface IPerson
    {
        string Förnamn { get; set; }
        string Efternamn { get; set; }
    }
}
