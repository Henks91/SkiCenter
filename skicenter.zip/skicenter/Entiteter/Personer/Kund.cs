﻿namespace Entiteter.Personer
{
    public abstract class Kund
    {

        public double MaxBeloppsKreditGräns { get; set; }
        public string Adress { get; set; }
        public string Postnummer { get; set; }
        public string Ort { get; set; }
        public string? Telefonnummer { get; set; }
        public string? MailAdress { get; set; }




    }
}
