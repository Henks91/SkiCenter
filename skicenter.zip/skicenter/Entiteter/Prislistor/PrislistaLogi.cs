﻿namespace Entiteter.Prislistor
{
    public class PrislistaLogi

    {

        public PrislistaLogi()
        {

        }


        public int PrisId { get; set; }
        public string TypAvLogi { get; set; }
        public int Vecka { get; set; }

        public int PrisVardag { get; set; }
        public int PrisHelg { get; set; }
        public int PrisVecka { get; set; }

        //public virtual Logi Logi { get; set; }
    }
}
