using System;

namespace Presentationslager.WPF
{
    public class Class1
    {
    }
}
