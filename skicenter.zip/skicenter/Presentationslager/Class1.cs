﻿namespace Presentationslager
{
    public class Class1
    {

    }
}