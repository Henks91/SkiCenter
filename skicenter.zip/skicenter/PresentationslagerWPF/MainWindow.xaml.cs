﻿using System.Windows;

namespace PresentationslagerWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //OBS. VÅR KONTROLLER HÄR
        //BokningKontroller bokningKontroller = new BokningKontroller();


        public MainWindow()
        {

            //OBS. Metoder för Startup
            InitializeComponent();
        }
    }
}
