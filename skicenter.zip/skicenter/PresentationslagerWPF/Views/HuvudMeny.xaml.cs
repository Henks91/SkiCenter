﻿using System.Windows.Controls;

namespace PresentationslagerWPF.Views
{
    /// <summary>
    /// Interaction logic for HuvudMeny.xaml
    /// </summary>
    public partial class HuvudMeny : UserControl
    {
        public HuvudMeny()
        {
            InitializeComponent();
        }
    }
}
