﻿using System.Windows.Controls;

namespace PresentationslagerWPF.Views
{
    /// <summary>
    /// Interaction logic for KundhanteringView.xaml
    /// </summary>
    public partial class KundhanteringView : UserControl
    {
        public KundhanteringView()
        {
            InitializeComponent();
        }

    }
}
