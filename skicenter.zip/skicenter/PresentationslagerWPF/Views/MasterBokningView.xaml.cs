﻿using System.Windows.Controls;

namespace PresentationslagerWPF.Views
{
    /// <summary>
    /// Interaction logic for MasterBokningView.xaml
    /// </summary>
    public partial class MasterBokningView : UserControl
    {
        public MasterBokningView()
        {
            InitializeComponent();
        }
    }
}
