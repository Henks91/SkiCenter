﻿using System.Windows.Controls;

namespace PresentationslagerWPF.Views
{
    /// <summary>
    /// Interaction logic for SkidshopView.xaml
    /// </summary>
    public partial class SkidshopView : UserControl
    {
        public SkidshopView()
        {
            InitializeComponent();
        }

    }
}
