﻿using System.Windows.Controls;

namespace PresentationslagerWPF.Views
{
    /// <summary>
    /// Interaction logic for StatistikView.xaml
    /// </summary>
    public partial class StatistikView : UserControl
    {
        public StatistikView()
        {
            InitializeComponent();
        }
    }
}
